#!/bin/bash
rivi=$(wget -O- http://www.hs.fi 2> /dev/null | grep 'class="congratulate"')
rivi=${rivi/<\/a>/}
rivi=${rivi/<*>/}
echo $rivi