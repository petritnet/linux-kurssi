#!/bin/bash
noppa1=$(((6 * $RANDOM / 32768)+1))
noppa2=$(((6 * $RANDOM / 32768)+1))
summa=$(($noppa1 + $noppa2))
echo "Noppa 1: $noppa1"
echo "Noppa 2: $noppa2"
echo "Mikä on silmälukujen summa?"
read vastaus
if [ "$vastaus" = "$summa" ]
then
  echo "Oikein!"
else
  echo "Väärin! Oikea vastaus oli $summa."
fi