#!/bin/bash
# Arvotaan kaksi lukua väliltä 1...6
# Arvotaan satunnaisluku ja otetaan sen jakojäännös 6:lla jaettaessa.
# Saatu luku on väliltä 0...5, joten lisätään siihen yksi.
noppa1=$((($RANDOM % 6)+1))
noppa2=$((($RANDOM % 6)+1))
# Lasketaan lukujen summa
summa=$(($noppa1 + $noppa2))
# Tulostetaan luvut ja kysytään käyttäjältä niiden summa.
echo "Noppa 1: $noppa1"
echo "Noppa 2: $noppa2"
echo "Mikä on silmälukujen summa?"
# Luetaan käyttäjän syöte stdin:istä muuttujaan vastaus.
read vastaus
# Jos vastaus on sama kuin summa, eli oikein, tulostetaan kehu, muuten moite ja oikea vastaus.
if [ "$vastaus" = "$summa" ]
then
  echo "Oikein!"
else
  echo "Väärin! Oikea vastaus oli $summa."
fi