#!/bin/bash
noppa1=$((($RANDOM % 6)+1))
noppa2=$((($RANDOM % 6)+1))
summa=$(($noppa1 + $noppa2))
echo "Noppa 1: $noppa1"
echo "Noppa 2: $noppa2"
echo "Mikä on silmälukujen summa?"
read vastaus
if [ "$vastaus" = "$summa" ]
then
  echo "Oikein!"
else
  echo "Väärin! Oikea vastaus oli $summa."
fi