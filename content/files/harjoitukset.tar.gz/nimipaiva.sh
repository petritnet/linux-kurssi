#!/bin/bash
wget -O- http://www.hs.fi 2> /dev/null | grep -oP '(?<=class="congratulate">)[^<]*'