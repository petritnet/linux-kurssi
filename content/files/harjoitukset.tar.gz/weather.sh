#!/bin/bash
weather=$(wget -O- "http://weather.yahooapis.com/forecastrss?w=574224&u=c" 2> /dev/null |grep -A1 'Current Conditions:' | tail -n 1); weather=${weather/<BR \/>/}
echo $weather