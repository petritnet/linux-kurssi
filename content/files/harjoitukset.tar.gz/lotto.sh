#!/bin/bash
times='5'
if [ -n "$1" ]
then
  times="$1"
fi
for i in $(seq $times)
do
  seq -w 1 39| sort -R| head -n 7 | sort | tr '\n' ' '
  echo
done