#!/bin/bash
# Arvotaan lottorivejä
# Oletuksena 5 riviä
times='5'
# Jos komentorivillä on annettu parametrina joku luku, käytetään sitä kertojen määränä.
if [ -n "$1" ]
then
  times="$1"
fi
# seq tulostaa luvut 1 ... $times. Suoritetaan silmukka kullakin luvulla.
for i in $(seq $times)
do
# Tulostetaan luvut 01...39 (etunollilla), järjestetään ne satunnaisesti, poimitaan 7 ensimmäistä,
# järjestetään järjestykseen ja korvataan rivinvaihdot välilyönneillä.
  seq -w 1 39| sort -R| head -n 7 | sort | tr '\n' ' '
# Tulostetaan pelkkä rivinvaihto
  echo
done